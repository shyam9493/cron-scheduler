"""mock-erp: the ONLY path to ERP data. Read-only FastAPI service over the erp schema."""
import logging
from contextlib import asynccontextmanager
from decimal import Decimal

import psycopg2
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

import db

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("mock-erp")


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_pool()          # raises -> container exits instead of starting broken
    yield
    db.close_pool()


app = FastAPI(title="Mock ERP", version="1.0", lifespan=lifespan)


# ---------------------------- models ----------------------------
class Vendor(BaseModel):
    vendor_id: str
    vendor_name: str
    country: str | None = None
    currency: str


class Sku(BaseModel):
    item_code: str
    category: str | None = None
    uom: str | None = None
    gst_rate: Decimal


class PoLine(BaseModel):
    item_code: str
    description: str | None = None
    qty: Decimal
    unit_price: Decimal
    currency: str


class PurchaseOrder(BaseModel):
    po_number: str
    vendor_id: str
    line_items: list[PoLine]


def _norm(value: str) -> str:
    return value.strip().upper()


# ---------------------------- routes ----------------------------
@app.get("/health")
def health():
    try:
        with db.get_cursor() as cur:
            cur.execute("SELECT 1 FROM erp.vendors LIMIT 1")
        return {"status": "ok"}
    except (psycopg2.Error, RuntimeError) as e:
        log.error("health check failed: %s", e)
        raise HTTPException(status_code=503, detail="database unavailable")


@app.get("/vendor/{vendor_id}", response_model=Vendor)
def get_vendor(vendor_id: str):
    with db.get_cursor() as cur:
        cur.execute(
            "SELECT vendor_id, vendor_name, country, currency FROM erp.vendors WHERE vendor_id = %s",
            (_norm(vendor_id),),
        )
        row = cur.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail=f"Vendor {vendor_id} not found")
    return row


@app.get("/po/{po_number}", response_model=PurchaseOrder)
def get_po(po_number: str):
    po = _norm(po_number)
    with db.get_cursor() as cur:
        cur.execute("SELECT po_number, vendor_id FROM erp.purchase_orders WHERE po_number = %s", (po,))
        header = cur.fetchone()
        if not header:
            raise HTTPException(status_code=404, detail=f"PO {po_number} not found")
        cur.execute(
            """SELECT item_code, description, qty, unit_price, currency
               FROM erp.po_line_items WHERE po_number = %s ORDER BY id""",
            (po,),
        )
        lines = cur.fetchall()
    return {**header, "line_items": lines}


@app.get("/sku/{sku_code}", response_model=Sku)
def get_sku(sku_code: str):
    with db.get_cursor() as cur:
        cur.execute(
            "SELECT item_code, category, uom, gst_rate FROM erp.sku_master WHERE item_code = %s",
            (_norm(sku_code),),
        )
        row = cur.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail=f"SKU {sku_code} not found")
    return row
