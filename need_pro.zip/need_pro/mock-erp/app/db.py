"""Postgres helper for mock-erp. Reads the `erp` schema only.

Credentials come from environment variables at runtime (never from source).
"""
import logging
import os
import time
from contextlib import contextmanager

import psycopg2
from psycopg2.extras import RealDictCursor
from psycopg2.pool import ThreadedConnectionPool

log = logging.getLogger("mock-erp.db")

_pool: ThreadedConnectionPool | None = None


# print(os.environ)

def _dsn() -> dict:
    try:
        return {
            "host":  "ep-soft-wave-b4pz9qhm-pooler.c-6.us-east-2.aws.neon.tech",
            "port": int(os.environ.get("POSTGRES_PORT", "5432")),
            "dbname": "neondb",
            "user":  "neondb_owner",
            "password":"npg_ITvMCag6N4qe",
            "connect_timeout": 5,
        }
    except KeyError as e:
        raise RuntimeError(f"Missing required environment variable: {e.args[0]}") from None


def init_pool(retries: int = 3, delay: float = 2.0) -> None:
    """Open the pool. Retries briefly, then raises so the container exits clearly."""
    global _pool
    dsn = _dsn()
    for attempt in range(1, retries + 1):
        try:
            _pool = ThreadedConnectionPool(1, 5, **dsn)
            log.info("Connected to postgres at %s:%s/%s", dsn["host"], dsn["port"], dsn["dbname"])
            return
        except psycopg2.OperationalError as e:
            log.error("Postgres connection failed (%d/%d): %s", attempt, retries, str(e).strip())
            if attempt == retries:
                raise RuntimeError("Cannot reach postgres - refusing to start") from e
            time.sleep(delay)


def close_pool() -> None:
    global _pool
    if _pool:
        _pool.closeall()
        _pool = None


@contextmanager
def get_cursor():
    """Yield a dict cursor; always return the connection to the pool."""
    if _pool is None:
        raise RuntimeError("Database pool not initialised")
    conn = _pool.getconn()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            yield cur
        conn.rollback()  # read-only service: never leave a transaction open
    except Exception:
        conn.rollback()
        raise
    finally:
        _pool.putconn(conn)
