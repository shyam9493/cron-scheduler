-- =====================================================================
-- AUDIT schema  (writer: agent only; streamlit-ui reads)
-- The durable business record. LangGraph checkpoints live separately.
-- Rules: line items are rows, money is NUMERIC, corrections are INSERTs.
-- =====================================================================
CREATE SCHEMA IF NOT EXISTS audit;
CREATE SCHEMA IF NOT EXISTS langgraph;   -- used by the LangGraph checkpointer

-- One row per successfully extracted invoice ---------------------------
CREATE TABLE IF NOT EXISTS audit.invoice_audit (
    invoice_id             UUID PRIMARY KEY,
    file_path              VARCHAR(512) NOT NULL,          -- reference, not the file
    file_checksum          VARCHAR(64)  NOT NULL UNIQUE,   -- SHA-256, detects reprocessing
    email_meta             JSONB,                          -- sender, subject, received_timestamp
    extraction_method      VARCHAR(32),                    -- pdfplumber | docx | tesseract
    raw_extracted_text     TEXT,                           -- full text, pre-translation
    translated_text        TEXT,
    source_language        VARCHAR(8),
    translation_confidence NUMERIC(4,3),
    invoice_number         VARCHAR(64),                    -- NULL allowed (malformed invoices)
    vendor_name            VARCHAR(255),
    vendor_id              VARCHAR(16),                    -- resolved via mock-erp from PO
    po_number              VARCHAR(64),
    invoice_date           DATE,
    currency               CHAR(3),
    subtotal_amount        NUMERIC(14,2),
    tax_amount             NUMERIC(14,2),
    total_amount           NUMERIC(14,2),
    missing_fields         JSONB DEFAULT '[]'::jsonb,
    validation_status      VARCHAR(16)
        CHECK (validation_status IN ('passed','failed','partial')),
    recommendation         VARCHAR(16)
        CHECK (recommendation IN ('approve','review','reject')),
    report_json            JSONB,                          -- latest report (DB = system of record)
    report_path            VARCHAR(512),                   -- HTML/JSON files on the volume
    extracted_raw          JSONB,                          -- variable leftovers
    thread_id              VARCHAR(128),                   -- links to langgraph state
    processed_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_validated_at      TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_inv_vendor   ON audit.invoice_audit(vendor_id);
CREATE INDEX IF NOT EXISTS idx_inv_reco     ON audit.invoice_audit(recommendation);
CREATE INDEX IF NOT EXISTS idx_inv_date     ON audit.invoice_audit(invoice_date);
CREATE INDEX IF NOT EXISTS idx_inv_po       ON audit.invoice_audit(po_number);

-- Line items: separate rows, never an array in the invoice row ---------
CREATE TABLE IF NOT EXISTS audit.invoice_line_items (
    id          BIGSERIAL PRIMARY KEY,
    invoice_id  UUID NOT NULL REFERENCES audit.invoice_audit(invoice_id) ON DELETE CASCADE,
    line_number INTEGER NOT NULL,
    item_code   VARCHAR(64),
    description TEXT,
    quantity    NUMERIC(12,3),
    unit_price  NUMERIC(14,4),
    line_total  NUMERIC(14,2),
    UNIQUE (invoice_id, line_number)
);

-- One row per mismatched field. Re-validation supersedes, never deletes -
CREATE TABLE IF NOT EXISTS audit.discrepancies (
    id             BIGSERIAL PRIMARY KEY,
    invoice_id     UUID NOT NULL REFERENCES audit.invoice_audit(invoice_id) ON DELETE CASCADE,
    validation_run INTEGER NOT NULL DEFAULT 1,             -- increments on each re-validation
    line_number    INTEGER,                                -- NULL = header-level
    field_name     VARCHAR(64) NOT NULL,
    invoice_value  TEXT,
    erp_value      TEXT,
    deviation_pct  NUMERIC(8,4),
    severity       VARCHAR(16) CHECK (severity IN ('low','medium','high','critical')),
    message        TEXT,
    is_active      BOOLEAN NOT NULL DEFAULT TRUE,          -- FALSE once superseded
    detected_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_disc_invoice ON audit.discrepancies(invoice_id, is_active);

-- Human corrections: INSERT only, original extraction is never overwritten
CREATE TABLE IF NOT EXISTS audit.human_feedback (
    id              BIGSERIAL PRIMARY KEY,
    invoice_id      UUID NOT NULL REFERENCES audit.invoice_audit(invoice_id) ON DELETE CASCADE,
    line_number     INTEGER,                               -- NULL = header field
    field_name      VARCHAR(64) NOT NULL,
    original_value  TEXT,
    corrected_value TEXT,
    comment         TEXT,
    corrected_by    VARCHAR(128) NOT NULL,
    corrected_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    revalidated     BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_fb_invoice ON audit.human_feedback(invoice_id, corrected_at);

-- Every file the monitor sees, including duplicates and failures --------
CREATE TABLE IF NOT EXISTS audit.processed_files (
    id                  BIGSERIAL PRIMARY KEY,
    file_path           VARCHAR(512) NOT NULL,
    file_name           VARCHAR(255) NOT NULL,
    file_checksum       VARCHAR(64),                        -- NOT unique: duplicates get their own row
    status              VARCHAR(16) NOT NULL
        CHECK (status IN ('processing','processed','duplicate','failed','unsupported')),
    invoice_id          UUID REFERENCES audit.invoice_audit(invoice_id),  -- original invoice for duplicates
    error_message       TEXT,
    detected_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_pf_checksum ON audit.processed_files(file_checksum);
