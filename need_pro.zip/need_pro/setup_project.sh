#!/usr/bin/env bash
# Usage: bash setup_project.sh [path/to/unzipped/"AI Invoice Auditor"]
# Creates the new_proj/ skeleton (empty files) and copies the dataset in.
set -euo pipefail

SRC="${1:-./AI Invoice Auditor}"
ROOT="new_proj"

mkdir -p "$ROOT"/{db,data/incoming,data/reports,data/samples,db/seed_json}
mkdir -p "$ROOT"/mock-erp/app
mkdir -p "$ROOT"/streamlit-ui/app
mkdir -p "$ROOT"/agent/{configs,app/services,app/utils,app/graph/nodes,app/rag}

cd "$ROOT"

# ---- root ----
touch compose.yaml .env.example .gitignore README.md

# ---- db ----
touch db/erp_schema.sql db/audit_schema.sql

# ---- data (keep empty dirs in git) ----
touch data/incoming/.gitkeep data/reports/.gitkeep

# ---- mock-erp ----
touch mock-erp/{Dockerfile,.dockerignore,requirements.txt}
touch mock-erp/app/{db.py,main.py}

# ---- streamlit-ui ----
touch streamlit-ui/{Dockerfile,.dockerignore,requirements.txt}
touch streamlit-ui/app/{db.py,main.py}

# ---- agent ----
touch agent/{Dockerfile,.dockerignore,requirements.txt}
touch agent/configs/{rules.yaml,persona.yaml}
touch agent/app/{main.py,config.py,db.py}
touch agent/app/services/{erp_client.py,bedrock_llm.py,cache.py,qdrant_store.py}
touch agent/app/utils/{checksum.py,extraction.py,field_parser.py}
touch agent/app/graph/{state.py,workflow.py}
touch agent/app/graph/nodes/{monitor.py,extractor.py,translation.py,data_validation.py,business_validation.py,reporting.py,rag_index.py}
touch agent/app/rag/{state.py,retrieval.py,augmentation.py,generation.py,reflection.py,pipeline.py}

# ---- python packages ----
for d in agent/app agent/app/services agent/app/utils agent/app/graph agent/app/graph/nodes agent/app/rag mock-erp/app streamlit-ui/app; do
  touch "$d/__init__.py"
done

# ---- copy dataset (if found) ----
if [ -d "../$SRC" ] || [ -d "$SRC" ]; then
  [ -d "../$SRC" ] && SRC="../$SRC"
  cp "$SRC/config/rules.yaml"       agent/configs/rules.yaml
  cp "$SRC/data/ERP_mockdata/"*.json db/seed_json/
  cp "$SRC/data/incoming/"*          data/samples/      # samples kept aside; incoming/ stays empty
  cp "$SRC/data/README.md"           data/samples/README.md
  echo "Dataset copied from: $SRC"
else
  echo "WARNING: dataset folder '$SRC' not found - skeleton created without sample data."
fi

echo; echo "Done. Structure:"
find . -not -path './.git*' | sort | sed 's|[^/]*/|  |g'
