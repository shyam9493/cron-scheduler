
flowchart TD
    A[Incoming invoice files] --> B[Agent monitor]
    B --> C[Extract and parse]
    C --> D[Translate]
    D --> E[Invoice validation]
    E --> F[Business validation]
    F --> G[Mock ERP HTTP API]
    G --> H[(PostgreSQL)]
    E --> H
    F --> H
    H --> I[Report generation]
    I --> H
    H --> J[RAG indexer]
    J --> K[(Qdrant)]
    L[Auditor dashboard] --> M[Agent API]
    M --> N{Query type}
    N -->|Structured| H
    N -->|Open-ended| K
    K --> O[Generate and reflect]
    O --> L
    L --> P[Human corrections]
    P --> M
    Q[(Redis cache)] -.-> D
    Q -.-> O
